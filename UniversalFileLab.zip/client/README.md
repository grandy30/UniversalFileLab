Client: run `npm install` and start using your preferred static server.
