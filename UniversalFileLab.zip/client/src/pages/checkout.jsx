import React, { useState } from "react";
import axios from "axios";

const Checkout = () => {
  const [amount, setAmount] = useState("");
  const [email, setEmail] = useState("");
  const [paymentUrl, setPaymentUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const response = await axios.post(`${process.env.REACT_APP_BACKEND_URL}/api/payments/create`, { amount, email, item_name: "UniversalFileLab Subscription" });
      if (response.data?.result?.checkout_url) setPaymentUrl(response.data.result.checkout_url);
      else setError("Failed to create payment.");
    } catch (err) {
      console.error(err);
      setError("Error connecting to backend.");
    } finally { setLoading(false); }
  };

  return (
    <div style={{ maxWidth: "500px", margin: "50px auto", textAlign: "center" }}>
      <h2>Pay with USDT</h2>
      <form onSubmit={handleSubmit}>
        <input type="number" min="0.1" step="0.01" placeholder="Amount" value={amount} onChange={(e)=>setAmount(e.target.value)} required/>
        <input type="email" placeholder="Email" value={email} onChange={(e)=>setEmail(e.target.value)} required/>
        <button type="submit">{loading ? "Processing..." : "Pay Now"}</button>
      </form>
      {paymentUrl && <a href={paymentUrl} target="_blank" rel="noopener noreferrer">Go to CoinPayments</a>}
      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
};

export default Checkout;
