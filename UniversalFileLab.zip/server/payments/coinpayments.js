import express from "express";
import axios from "axios";
import crypto from "crypto";
import pool from "../../db.js";

const router = express.Router();

router.post("/create", async (req, res) => {
  try {
    const { amount, currency = "USDT", item_name, email } = req.body;

    const payload = new URLSearchParams();
    payload.append("version", 1);
    payload.append("cmd", "create_transaction");
    payload.append("amount", amount);
    payload.append("currency1", currency);
    payload.append("currency2", currency);
    payload.append("buyer_email", email);
    payload.append("item_name", item_name);
    payload.append("ipn_url", process.env.COINPAYMENTS_IPN_URL);

    const auth = {
      username: process.env.COINPAYMENTS_PUBLIC_KEY,
      password: process.env.COINPAYMENTS_PRIVATE_KEY
    };

    const response = await axios.post(
      "https://www.coinpayments.net/api.php",
      payload,
      { auth }
    );

    // Save pending transaction
    await pool.query(
      "INSERT INTO payments(txn_id, amount, currency, status, email) VALUES($1,$2,$3,$4,$5)",
      [response.data.result.txn_id, amount, currency, "pending", email]
    );

    res.json(response.data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create transaction" });
  }
});

// IPN listener
router.post("/ipn", async (req, res) => {
  const hmac = req.headers["hmac"];
  const generatedHmac = crypto
    .createHmac("sha512", process.env.COINPAYMENTS_IPN_SECRET)
    .update(req.rawBody || "")
    .digest("hex");

  if (hmac !== generatedHmac) return res.status(403).send("Invalid IPN");

  const { txn_id, status } = req.body;

  await pool.query("UPDATE payments SET status=$1 WHERE txn_id=$2", [status, txn_id]);

  res.send("OK");
});

export default router;
