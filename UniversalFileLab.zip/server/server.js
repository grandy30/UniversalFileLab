import express from "express";
import dotenv from "dotenv";
import bodyParser from "body-parser";
import fs from "fs";
import path from "path";
import pool from "./db.js";
import paymentRoutes from "./api/payments/coinpayments.js";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 5000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use("/api/payments/ipn", bodyParser.raw({ type: "*/*" }));
app.use("/api/payments", paymentRoutes);

async function runMigrations() {
  const migrationsDir = path.join(process.cwd(), "migrations");
  if (!fs.existsSync(migrationsDir)) return;
  const files = fs.readdirSync(migrationsDir).filter(f => f.endsWith(".sql"));
  for (const file of files) {
    const sql = fs.readFileSync(path.join(migrationsDir, file), "utf8");
    await pool.query(sql);
    console.log(`Migration applied: ${file}`);
  }
}

runMigrations()
  .then(() => {
    console.log("✅ All migrations applied.");
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  })
  .catch(err => {
    console.error("❌ Migration error:", err);
    process.exit(1);
  });
